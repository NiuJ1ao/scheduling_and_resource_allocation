## Prerequisite
This code runs Python 3.8 with the following libraries:
- numpy
pip install numpy
- tabulate (optional for printing intermediate results)
pip install tabulate

## Run
python lcl_rule.py --workflow_file input.json --process_time_file process_times.txt --dump_schedule
